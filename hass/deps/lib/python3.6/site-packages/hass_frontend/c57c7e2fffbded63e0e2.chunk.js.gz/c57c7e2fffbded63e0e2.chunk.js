(window.webpackJsonp=window.webpackJsonp||[]).push([[33],{708:function(module,__webpack_exports__,__webpack_require__){"use strict";__webpack_require__.r(__webpack_exports__);var _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__=__webpack_require__(0),_polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__=__webpack_require__(4),_layouts_partial_cards__WEBPACK_IMPORTED_MODULE_2__=__webpack_require__(268);class HaPanelKiosk extends _polymer_polymer_polymer_element__WEBPACK_IMPORTED_MODULE_1__.a{static get template(){return _polymer_polymer_lib_utils_html_tag__WEBPACK_IMPORTED_MODULE_0__.a`
      <partial-cards
        id="kiosk-states"
        hass="[[hass]]"
        show-menu
        route="[[route]]"
        panel-visible
      ></partial-cards>
    `}static get properties(){return{hass:Object,route:Object}}}customElements.define("ha-panel-kiosk",HaPanelKiosk)}}]);
//# sourceMappingURL=c57c7e2fffbded63e0e2.chunk.js.map